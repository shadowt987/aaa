<?php
require 'db.php';

class Service {
  private $authorized_user_id = "ANlOHQNiRBD5YjrE5cmxzJEdNe7PxoE8Cw==";
  private $privkey = <<<EOD
-----BEGIN RSA PRIVATE KEY-----
MIIEpQIBAAKCAQEAyRnRroAiaNP914ylV8SKTqYqsH3F775vScKD+i1ZCHgdi0QH
fW3t0w/5t68PmwQYIP9eyXuyTfgqce+M3FLdnS44W3FcLyVs7wQFbslMgcfjXYbh
sTL12sif5GY9InyfGIIR2fWYz1MbC0EUIrKdJumm21AHS/66F4EhfRtHoHP9OYHE
W/vHJ1RICuKFRU0zy+sogpEqVYU/FodnTddPlFES6A6BFMT4CU27TU52NGa//CBc
scVTXerW8bJPHNrvNe7CmHeqTLhFNyCLtE/8dJklsWFOfTvKT39E2W6EVBT4HzzJ
hfYF961An3AWPKbDd3vz4r/Gr19saGWUgJKiTwIDAQABAoIBAQC3pnaQz7+c0Ax/
bpgIwRo1nRZbO2EqAlWLnLH+JK+sRlVku2nDqEKKf4pjruGnhWOrrssXYXmCLuJE
TqnrA1oTkwQwriOrgpgq5xc3B2pxEuSWovk1Y/6WIKW0ZZHrDrgUH6TB0cINhC2s
Z3BGB6vwv2x72GfxhNzZXjoBEIqnAeSyqS/4eXrSFwffUplHQBRSHJXPCRz+mfrh
lSdQCUVi08kC33g1b4csz227cW6wI9MdMpYW1EvAkQPNosHDnjHeSMetjX2JTBSF
Jv5KHbMNyCkqJX6iVS0wSQ0/p6Rb8iDBkBzM08zDY1AFolJ3yDsOWubH3F9T3jTY
/uPPhMkBAoGBAP84wgscjajO9NKYGJHsOnmm3NlIAtDU9OOsXfRpZ1iUGz+W38Gi
nrV92JjPk/6Ppbjy/mbI1hY4AgvBrGHv5JXN2kjXr47cn4zEEWwndK/oZtTG0GH0
BpfbhRnzUV8HYbbI9AyAaBSVn/eRcnF4XmyUJhlpBzYfwpaY1cRJBjcPAoGBAMm2
z5tm3HgI5ED9RUo69pnd8ffRd0cERKiY5W0n1DYmvofT1AdpstHnP0NqHbFoKKML
MhSqp45ubKeSTlGu9cLbydGXbFPV9ZHnuMzJgEfEjMLWkicK3SvKjMn2Wv8LbyXp
dLDjF+6qhMNbgO62mcBHmMw8tlo8y9/iE0dh6uDBAoGBALwBfoea6AuDMLv1iJvt
zYGR1rxEnLZjOWaBsdB62MNajtv/8yJ7/beqVaTzvIxYGvcsIRVsOrCxX2hzqd2X
Tua/dl4UbGGryehzAnaOdhmi9CUns5eEoFq7PchJAhcjo+p3C7gt2v3W3rkLLqfB
yKTpWUt8n/BR4xD20vm95VMnAoGASQ2bPKXRHOvjdqIDUTHvk6Qs+Np0v1SNZR4S
oSi2k3IOuPR/qrueFqUQZWLuJA0cAoiQd6mii1P0p++1y6F4wjyFaBHWGrq3eEMa
y5gCjHtjm0DIp7kohq6RtKczJ4FFnM5jA5kLVtWMxY/DLzEUl+2WKgmm5SF1mLyw
zL5qqUECgYEA3bkEIUDNOnZQRX0DxnJNTPNnFC5L4wXaadoaMhsZe8xZbHkuIAq8
QUJbqbp7BTxn96CcwnCdAkoPYlfAP8utrwn9PZkq9FVO4bhld5elk7wZb/vweYFQ
/CFRAPd17aV35VqggJeJ8DoOsGFow/SpSnXqIKnt8P4fVE44C6p5nU4=
-----END RSA PRIVATE KEY-----
EOD;

  private $db;

  public function __construct() {
    $this->db = new DB();
  }

  private function decrypt($message) {
    if (openssl_private_decrypt(base64_decode($message), $decrypted, openssl_get_privatekey($this->privkey)))
      try {
        return json_decode($decrypted, true);
      } catch (Exception $e) {
        file_put_contents('php://stderr', print_r("JSON decoding failed", TRUE));
        return array();
      }
    else {
      file_put_contents('php://stderr', print_r("Decryption failed", TRUE));
      return array();
    }
  }

  public function register($message) {
    $data = $this->decrypt($message);
    if (count($data) > 0) {
      $user_id = $data["user_id"];
      if (isset($user_id) && $user_id == $this->authorized_user_id) {
          $device_id = $data["device_id"];
          $license_key = $data["license_key"];
          if (isset($device_id, $license_key) && $device_id != "" && $license_key != "")
            try {
              $this->db->insert_license($device_id, $license_key);
              return true;
            } catch (Exception $e) { /* Not inserted or updated due to exception, return false */ }
      }
    }
    return false;
  }

  public function check_license($message) {
    $data = $this->decrypt($message);
    if (count($data) > 0) {
      $device_id = $data["device_id"];
      $license_key = $data["license_key"];
      if (isset($device_id, $license_key) && $device_id != "" && $license_key != "")
        try {
          $registered_license_key = $this->db->get_license_key($device_id);
          return $registered_license_key == $license_key;
        } catch (Exception $e) { /* Could not check license due to exception, return false */ }
    }
    return false;
  }

  public function check_device($message) {
    $data = $this->decrypt($message);
    if (count($data) > 0) {
      $user_id = $data["user_id"];
      $device_id = $data["device_id"];
      if (isset($user_id, $device_id) && $user_id != "" && $device_id != "")
        try {
          return $this->db->is_user_device_registered($user_id, $device_id) ||
                ($this->db->get_device_count($user_id) < 3 && $this->db->insert_user_device($user_id, $device_id));
        } catch (Exception $e) { /* Could not check device license due to exception, return false */ }
    }
    return false;
  }
}

?>
