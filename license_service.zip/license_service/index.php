<?php
require 'vendor/autoload.php';
require 'service.php';

$app = new \Slim\App();

/*$app->get('/madcast/info/', function ($request, $response, $args) {
  phpinfo();
});*/

$app->post('/madcast/register/', function ($request, $response, $args) {
  $message = $request->getBody();
  //file_put_contents('php://stderr', print_r("HTTP body received: ".$message, TRUE));
  $service = new Service();
  $result = $service->register($message);
  if ($result)
    $response->write("Registered");
  else {
    $response = $response->withStatus(403);
    $response->write("Not allowed");
  }
  return $response;
});

$app->post('/madcast/check_license/', function ($request, $response, $args) {
  $message = $request->getBody();
  $service = new Service();
  $result = $service->check_license($message);
  if ($result)
    $response->write("Authorized");
  else {
    $response = $response->withStatus(403);
    $response->write("Forbidden");
  }
  return $response;
});

$app->post('/madcast/check_device/', function ($request, $response, $args) {
  $message = $request->getBody();
  $service = new Service();
  $result = $service->check_device($message);
  if ($result)
    $response->write("Authorized");
  else {
    $response = $response->withStatus(403);
    $response->write("Forbidden");
  }
  return $response;
});

$app->run();

?>
