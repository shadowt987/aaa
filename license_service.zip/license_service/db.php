
<?php

class DB {

  private $conn;
  private $host="localhost";
  //private $host = "vps58718.ovh.net";
  private $dbname = "madcast";
  private $user = "root";
  private $pass = "m4dc45T";

  public function __construct() {
      $this->conn = new PDO('mysql:host='.$this->host.';dbname='.$this->dbname, $this->user, $this->pass);
  }

  public function insert_license($device_id, $license_key) {
    return ($this->conn->exec("insert into license (device_id, license_key) values ('$device_id', '$license_key')") > 0 ||
            $this->conn->exec("update license set license_key='$license_key' where device_id='$device_id'") > 0);

  }

  public function get_license_key($device_id) {
    if ($stmt = $this->conn->query("select license_key from license where device_id='$device_id'")) {
      $row = $stmt->fetch();
      return $row["license_key"];
    }
    return "";
  }

  public function is_user_device_registered($user_id, $device_id) {
    if ($stmt = $this->conn->query("select count(device_id) as device_count from user_devices where user_id='$user_id' and device_id='$device_id'")) {
      $row = $stmt->fetch();
      return $row["device_count"] > 0;
    }
    return false;
  }

  public function get_device_count($user_id) {
    if ($stmt = $this->conn->query("select count(device_id) as devices_count from user_devices where user_id='$user_id'")) {
      $row = $stmt->fetch();
      return $row["devices_count"];
    }
    return 0;
  }

  public function insert_user_device($user_id, $device_id) {
    return $this->conn->exec("insert into user_devices (user_id, device_id) values ('$user_id', '$device_id')") > 0;
  }
}

?>
